# TLPT Poker League Site V2

A static poker league website with:
- homepage hero and next-game card
- dashboard for power / skill / luck / clutch / bubble views
- sortable standings table
- player roster and individual profile pages
- champions archive
- schedule page with Apple Invites RSVP links
- rules page
- CSV-to-JSON stat refresh script

## Cheapest publishing option
Use GitHub Pages, Netlify, or Cloudflare Pages. GitHub Pages is the easiest free long-term option.

## Weekly RSVP workflow
This build is designed around **Apple Invites** as the RSVP engine.

For each event in `data/stats.json`, update:
- `apple_invite_url`
- `guest_list_url`
- `rsvp_counts.confirmed`
- `rsvp_counts.maybe`
- `rsvp_counts.out`

## Updating stats from your analysis sheet
1. Export your player stats into CSV.
2. Save it over `data/analysis_export.csv`.
3. Run:

```bash
python scripts/update_from_csv.py data/analysis_export.csv data/stats.json
```

## Recommended next customizations
- swap sample TLPT player data for your real league stat pack
- replace sample event links with your Apple Invites URLs
- add logo / banner art
- wire in additional metrics from your TLPT Ultimate Stat Pack

## Pages
- `index.html`
- `dashboard.html`
- `standings.html`
- `players.html`
- `champions.html`
- `schedule.html`
- `rules.html`
- `players/*.html`


## Update from the Excel workbook

```bash
python scripts/update_from_xlsx.py TLPT_Ultimate_Analytics_Template.xlsx data/stats.json
```

This reads the `Master Metrics` sheet and refreshes the site data while leaving your event/invite links intact.
