#!/usr/bin/env python3
import json, csv, re, sys
from pathlib import Path
import openpyxl

def slugify(name):
    return re.sub(r"[^a-z0-9]+", "", name.lower()) or "player"

def initials(name):
    parts = [p for p in re.split(r"[\s\-\.]+", name.strip()) if p]
    return ((parts[0][0] + parts[-1][0]) if len(parts) >= 2 else name[:2]).upper()

def pct(x):
    return int(round(float(x or 0) * 100))

def nice_int(x):
    return int(round(float(x or 0)))

if len(sys.argv) != 3:
    print("Usage: python scripts/update_from_xlsx.py INPUT.xlsx data/stats.json")
    sys.exit(1)

xlsx_path = Path(sys.argv[1])
json_path = Path(sys.argv[2])

wb = openpyxl.load_workbook(xlsx_path, data_only=False)
ws = wb["Master Metrics"]
rows = list(ws.iter_rows(values_only=True))
headers = list(rows[0])
records = [dict(zip(headers, row)) for row in rows[1:] if row[0]]
max_entries = max(r["Entries"] for r in records)

players = []
for r in records:
    players.append({
        "id": slugify(r["Name"]),
        "name": r["Name"],
        "nickname": "TLPT Regular",
        "avatar": initials(r["Name"]),
        "entries": nice_int(r["Entries"]),
        "cashes": nice_int(r["Times Placed"]),
        "buyins": nice_int(r["Buy-ins"]),
        "rebuys": nice_int(r["Rebuys"]),
        "knockouts": nice_int(r["Hits"]),
        "bubbleFinishes": nice_int(r["Bubble"]),
        "profit": nice_int(r["Profit"]),
        "roi": pct(r["ROI"]),
        "cashRate": pct(r["CashRate"]),
        "bubbleRate": pct(r["BubbleRate"]),
        "hitRate": pct(r["HitRate"]),
        "powerRank": nice_int(r["SkillRank"]),
        "profitRank": nice_int(r["ProfitRank"]),
        "skillIndex": nice_int(r["TrueSkillScore"]),
        "luckIndex": nice_int(r["LuckIndex"]),
        "clutchIndex": nice_int(r["ClutchIndex"]),
        "attendanceRate": int(round(r["Entries"] / max_entries * 100)),
        "bio": f'{nice_int(r["Times Placed"])} cashes in {nice_int(r["Entries"])} entries.',
        "bestFinish": f'{nice_int(r["Times Placed"])} cashes',
        "favoriteMoment": f'{nice_int(r["Hits"])} hits and a {pct(r["ROI"])}% ROI.'
    })

players.sort(key=lambda p: p["powerRank"])

with open(json_path) as f:
    data = json.load(f)

data["players"] = players
data["featured"]["mostDangerous"] = players[0]["name"]
data["featured"]["bubbleKing"] = max(players, key=lambda p: p["bubbleFinishes"])["name"]

with open(json_path, "w") as f:
    json.dump(data, f, indent=2)

print(f"Updated {json_path} from {xlsx_path}")
