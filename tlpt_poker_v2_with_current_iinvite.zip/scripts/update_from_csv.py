"""Convert a CSV export into the site's player stats JSON structure.

Expected columns (case-sensitive in this starter template):
name,id,nickname,avatar,wins,cashes,buyins,rebuys,knockouts,bubbleFinishes,roi,powerRank,skillIndex,luckIndex,clutchIndex,attendanceRate,bio,bestFinish,favoriteMoment

Usage:
  python scripts/update_from_csv.py data/analysis_export.csv data/stats.json
"""
import csv, json, sys
from pathlib import Path

NUMERIC_FIELDS = {
    "wins": int,
    "cashes": int,
    "buyins": int,
    "rebuys": int,
    "knockouts": int,
    "bubbleFinishes": int,
    "roi": int,
    "powerRank": int,
    "skillIndex": int,
    "luckIndex": int,
    "clutchIndex": int,
    "attendanceRate": int,
}


def main(csv_path: str, json_path: str) -> None:
    csv_file = Path(csv_path)
    json_file = Path(json_path)
    data = json.loads(json_file.read_text())
    players = []
    with csv_file.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            clean = {k: v for k, v in row.items()}
            for field, caster in NUMERIC_FIELDS.items():
                clean[field] = caster(clean.get(field) or 0)
            players.append(clean)
    data["players"] = players
    if players:
        ranked = sorted(players, key=lambda p: p.get("powerRank", 999))
        data["featured"]["currentChampion"] = ranked[0]["name"]
        data["featured"]["mostDangerous"] = max(players, key=lambda p: p.get("clutchIndex", 0))["name"]
        data["featured"]["bubbleKing"] = max(players, key=lambda p: p.get("bubbleFinishes", 0))["name"]
    json_file.write_text(json.dumps(data, indent=2))
    print(f"Updated {json_file} with {len(players)} players")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python scripts/update_from_csv.py <input.csv> <stats.json>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
