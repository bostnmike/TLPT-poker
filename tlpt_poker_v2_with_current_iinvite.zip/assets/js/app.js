
async function loadData() {
  const res = await fetch('data/stats.json');
  return res.json();
}

function setActiveNav() {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === page) a.classList.add('active');
  });
}

function formatDate(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString(undefined, { weekday:'short', month:'short', day:'numeric', year:'numeric' });
}

function nextEvent(events) {
  return [...events].sort((a,b)=> new Date(a.date)-new Date(b.date))[0];
}

function topBy(players, key, count=5) {
  return [...players].sort((a,b)=> (b[key]||0) - (a[key]||0)).slice(0,count);
}

function renderSiteChrome(site) {
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = site.name);
  document.querySelectorAll('[data-site-tagline]').forEach(el => el.textContent = site.tagline);
  document.querySelectorAll('[data-season]').forEach(el => el.textContent = site.season);
}

function createPlayerChip(p) {
  return `<span class="player-chip"><span class="avatar">${p.avatar}</span>${p.name}</span>`;
}

function money(v) {
  const n = Number(v || 0);
  const sign = n > 0 ? '+' : '';
  return `${sign}$${n}`;
}

function renderHome(data) {
  const evt = nextEvent(data.events);
  const leaderboard = [...data.players].sort((a,b)=>a.powerRank-b.powerRank).slice(0,5);
  document.getElementById('nextGame').innerHTML = `
    <div class="badge">Next Game</div>
    <h3>${evt.title}</h3>
    <p><strong>${formatDate(evt.date)}</strong> • ${evt.time}<br>${evt.location}<br>${evt.format}</p>
    <p class="subtle">${evt.buyin}</p>
    <div class="rsvp-stats">
      <span class="pill confirmed">${evt.rsvp_counts.confirmed} confirmed</span>
      <span class="pill maybe">${evt.rsvp_counts.maybe} maybe</span>
      <span class="pill out">${evt.rsvp_counts.out} out</span>
    </div>
    <div class="actions">
      <a class="btn btn-primary" href="${evt.apple_invite_url}" target="_blank" rel="noopener">RSVP in Apple Invites</a>
      <a class="btn btn-secondary" href="schedule.html">Full Schedule</a>
    </div>
    <p class="note">${evt.notes || ''}</p>`;

  document.getElementById('leaderboardPreview').innerHTML = `
    <table>
      <thead><tr><th>Rank</th><th>Player</th><th>Skill</th><th>Profit</th></tr></thead>
      <tbody>
        ${leaderboard.map(p=>`<tr><td>#${p.powerRank}</td><td>${createPlayerChip(p)}</td><td>${p.skillIndex}</td><td>${money(p.profit)}</td></tr>`).join('')}
      </tbody>
    </table>`;

  const stats = {
    players: data.players.length,
    entries: data.players.reduce((s,p)=>s+(p.entries||0),0),
    knockouts: data.players.reduce((s,p)=>s+(p.knockouts||0),0),
    avgROI: Math.round(data.players.reduce((s,p)=>s+(p.roi||0),0)/data.players.length)
  };
  document.getElementById('quickStats').innerHTML = `
    <div class="stat"><div class="label">Players</div><div class="value">${stats.players}</div></div>
    <div class="stat"><div class="label">Total Entries</div><div class="value">${stats.entries}</div></div>
    <div class="stat"><div class="label">Total Hits</div><div class="value">${stats.knockouts}</div></div>
    <div class="stat"><div class="label">Avg ROI</div><div class="value">${stats.avgROI}%</div></div>`;

  document.getElementById('featuredCards').innerHTML = `
    <div class="card"><div class="kicker">Current Champion</div><h3>${data.featured.currentChampion}</h3><p class="subtle">Keep this synced to the latest winner.</p></div>
    <div class="card"><div class="kicker">Most Dangerous</div><h3>${data.featured.mostDangerous}</h3><p class="subtle">Current top-ranked player from the workbook.</p></div>
    <div class="card"><div class="kicker">Bubble Radar</div><h3>${data.featured.bubbleKing}</h3><p class="subtle">Leads the loaded sheet in bubble finishes.</p></div>`;
}

function renderDashboard(data) {
  document.getElementById('dashboardStats').innerHTML = `
    <div class="stat"><div class="label">Skill Leader</div><div class="value">${topBy(data.players,'skillIndex',1)[0].name}</div></div>
    <div class="stat"><div class="label">Luck Leader</div><div class="value">${topBy(data.players,'luckIndex',1)[0].name}</div></div>
    <div class="stat"><div class="label">Clutch Leader</div><div class="value">${topBy(data.players,'clutchIndex',1)[0].name}</div></div>
    <div class="stat"><div class="label">KO Leader</div><div class="value">${topBy(data.players,'knockouts',1)[0].name}</div></div>`;

  const power = [...data.players].sort((a,b)=>a.powerRank-b.powerRank);
  const maxSkill = Math.max(...data.players.map(p=>p.skillIndex || 0), 1);
  const rows = power.map(p=>`<div class="bar-row"><div>${p.name}</div><div class="bar-track"><div class="bar-fill" style="width:${Math.max(8, Math.round((p.skillIndex/maxSkill)*100))}%"></div></div><div>${p.skillIndex}</div></div>`).join('');
  document.getElementById('skillBars').innerHTML = rows;

  const bubble = [...data.players].sort((a,b)=>b.bubbleFinishes-a.bubbleFinishes || a.powerRank-b.powerRank).map(p=>`<tr><td>${createPlayerChip(p)}</td><td>${p.bubbleFinishes}</td><td>${p.bubbleRate}%</td><td>${p.clutchIndex}</td></tr>`).join('');
  document.getElementById('bubbleTable').innerHTML = `<table><thead><tr><th>Player</th><th>Bubbles</th><th>Bubble Rate</th><th>Clutch</th></tr></thead><tbody>${bubble}</tbody></table>`;
}

function renderStandings(data) {
  const tbody = document.getElementById('standingsBody');
  tbody.innerHTML = [...data.players].sort((a,b)=>a.powerRank-b.powerRank).map(p=>`<tr>
    <td>${p.powerRank}</td>
    <td>${createPlayerChip(p)}</td>
    <td>${p.entries}</td>
    <td>${p.cashes}</td>
    <td>${p.buyins}</td>
    <td>${p.rebuys}</td>
    <td>${p.knockouts}</td>
    <td>${money(p.profit)}</td>
    <td>${p.skillIndex}</td>
    <td>${p.luckIndex}</td>
    <td>${p.clutchIndex}</td>
    <td>${p.roi}%</td>
  </tr>`).join('');

  document.querySelectorAll('th[data-sort]').forEach(th => {
    th.addEventListener('click', ()=> sortTable(th.dataset.sort, tbody, data.players));
  });
}

function sortTable(key, tbody, players) {
  const isNumeric = ['powerRank','entries','cashes','buyins','rebuys','knockouts','profit','skillIndex','luckIndex','clutchIndex','roi'].includes(key);
  const sorted = [...players].sort((a,b)=> isNumeric ? ((b[key]||0)-(a[key]||0)) : String(a[key]).localeCompare(String(b[key])));
  if (key==='powerRank') sorted.sort((a,b)=>a.powerRank-b.powerRank);
  tbody.innerHTML = sorted.map(p=>`<tr>
    <td>${p.powerRank}</td><td>${createPlayerChip(p)}</td><td>${p.entries}</td><td>${p.cashes}</td><td>${p.buyins}</td><td>${p.rebuys}</td><td>${p.knockouts}</td><td>${money(p.profit)}</td><td>${p.skillIndex}</td><td>${p.luckIndex}</td><td>${p.clutchIndex}</td><td>${p.roi}%</td>
  </tr>`).join('');
}

function renderPlayers(data) {
  document.getElementById('playerGrid').innerHTML = data.players.map(p=>`<a class="card player-card" href="players/${p.id}.html">
    <div class="player-chip"><span class="avatar">${p.avatar}</span><div><div>${p.name}</div><div class="meta">${p.nickname}</div></div></div>
    <p class="subtle">${p.bio}</p>
    <div class="mini-stats"><div><strong>#${p.powerRank}</strong><br><span class="subtle">Power</span></div><div><strong>${p.skillIndex}</strong><br><span class="subtle">Skill</span></div><div><strong>${money(p.profit)}</strong><br><span class="subtle">Profit</span></div></div>
  </a>`).join('');
}

function renderSchedule(data) {
  document.getElementById('eventList').innerHTML = data.events.map(evt => `
    <div class="card event-card">
      <div>
        <div class="kicker">${formatDate(evt.date)}</div>
        <h3>${evt.title}</h3>
        <p><strong>${evt.time}</strong> • ${evt.location}<br>${evt.format}<br>${evt.buyin}</p>
        <p class="subtle">${evt.notes || ''}</p>
      </div>
      <div>
        <div class="badge">RSVP Status</div>
        <div class="rsvp-stats">
          <span class="pill confirmed">${evt.rsvp_counts.confirmed} confirmed</span>
          <span class="pill maybe">${evt.rsvp_counts.maybe} maybe</span>
          <span class="pill out">${evt.rsvp_counts.out} out</span>
        </div>
        <div class="rsvp-row">
          <a class="btn btn-primary" href="${evt.apple_invite_url}" target="_blank" rel="noopener">RSVP in Apple Invites</a>
          ${evt.guest_list_url ? `<a class="btn btn-secondary" href="${evt.guest_list_url}" target="_blank" rel="noopener">View Guest List</a>` : ''}
        </div>
      </div>
    </div>`).join('');
}

function renderChampions(data) {
  document.getElementById('championList').innerHTML = data.champions.map(c=>`
    <div class="card"><div class="kicker">${c.season}</div><h3>${c.name}</h3><p class="subtle">${c.note}</p></div>
  `).join('');
}

function renderRules(data) {
  const r = data.rules;
  document.getElementById('rulesPanel').innerHTML = `
    <div class="stat-grid">
      <div class="stat"><div class="label">Buy-In</div><div class="value" style="font-size:1.2rem">${r.buyin}</div></div>
      <div class="stat"><div class="label">Rebuys</div><div class="value" style="font-size:1.2rem">${r.rebuys}</div></div>
      <div class="stat"><div class="label">Payouts</div><div class="value" style="font-size:1.2rem">${r.payouts}</div></div>
      <div class="stat"><div class="label">Late Policy</div><div class="value" style="font-size:1.2rem">${r.latePolicy}</div></div>
    </div>
    <div class="card" style="margin-top:18px"><h3>House Rules</h3><ul>${r.houseRules.map(x=>`<li>${x}</li>`).join('')}</ul></div>`;
}

async function buildPlayerPages() {
  const data = await loadData();
  const path = location.pathname.split('/').pop();
  const id = path.replace('.html','');
  const p = data.players.find(x=>x.id===id);
  if (!p) return;
  renderSiteChrome(data.site);
  document.getElementById('playerName').textContent = p.name;
  document.getElementById('playerNick').textContent = p.nickname;
  document.getElementById('playerBio').textContent = p.bio;
  document.getElementById('playerAvatar').textContent = p.avatar;
  document.getElementById('playerStats').innerHTML = `
    <div class="stat"><div class="label">Power Rank</div><div class="value">#${p.powerRank}</div></div>
    <div class="stat"><div class="label">Entries</div><div class="value">${p.entries}</div></div>
    <div class="stat"><div class="label">Cashes</div><div class="value">${p.cashes}</div></div>
    <div class="stat"><div class="label">Hits</div><div class="value">${p.knockouts}</div></div>
    <div class="stat"><div class="label">Profit</div><div class="value">${money(p.profit)}</div></div>
    <div class="stat"><div class="label">ROI</div><div class="value">${p.roi}%</div></div>
    <div class="stat"><div class="label">Skill Index</div><div class="value">${p.skillIndex}</div></div>
    <div class="stat"><div class="label">Luck Index</div><div class="value">${p.luckIndex}</div></div>
    <div class="stat"><div class="label">Clutch Index</div><div class="value">${p.clutchIndex}</div></div>
    <div class="stat"><div class="label">Bubble Rate</div><div class="value">${p.bubbleRate}%</div></div>`;
  document.getElementById('playerNotes').innerHTML = `<p><strong>Best finish note:</strong> ${p.bestFinish}</p><p><strong>Snapshot:</strong> ${p.favoriteMoment}</p><p><strong>Cash rate:</strong> ${p.cashRate}% • <strong>Hit rate:</strong> ${p.hitRate}%</p>`;
  setActiveNav();
}

async function init() {
  setActiveNav();
  const data = await loadData();
  renderSiteChrome(data.site);
  const page = document.body.dataset.page;
  if (page === 'home') renderHome(data);
  if (page === 'dashboard') renderDashboard(data);
  if (page === 'standings') renderStandings(data);
  if (page === 'players') renderPlayers(data);
  if (page === 'schedule') renderSchedule(data);
  if (page === 'champions') renderChampions(data);
  if (page === 'rules') renderRules(data);
}

if (document.body.dataset.page === 'player') {
  buildPlayerPages();
} else {
  init();
}
